<!-- IMAGE UPLOAD WITH PREVIEW -->
<link rel="stylesheet" href="<?php echo base_url('assets/backend/'); ?>css/file-upload-preview.css">
<!-- Select2 -->
<link rel="stylesheet" href="<?php echo base_url('assets/backend/'); ?>plugins/select2/css/select2.min.css">
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo base_url('assets/backend/'); ?>plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo base_url('assets/backend/'); ?>plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
<!-- DateRange -->
<link rel="stylesheet" href="<?php echo base_url('assets/backend/'); ?>plugins/daterangepicker/daterangepicker.css">