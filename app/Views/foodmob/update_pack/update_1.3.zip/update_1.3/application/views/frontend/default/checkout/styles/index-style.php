<style>
.callout-none {
    border: 1px solid #e0e0e0 !important;
    border-left-width: 1px !important;
}
.payment-gateways img {
    height: 60px;
}

.payment-gateways .callout {
    margin : 5px 0px;
}

label {
    width: 100%;
}

input[type=radio] {
    display: none;
}
</style>
