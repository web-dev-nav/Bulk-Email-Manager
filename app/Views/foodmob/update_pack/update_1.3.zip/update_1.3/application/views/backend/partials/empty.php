<div class="row justify-content-center empty-img">
    <img src="<?php echo base_url('assets/backend/img/empty.png'); ?>">
</div>
<div class="row justify-content-center empty-title">
    <?php echo get_phrase("no_data_found"); ?>
</div>
