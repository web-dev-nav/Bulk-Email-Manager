<!-- DataTables -->
<link rel="stylesheet" href="<?php echo base_url('assets/backend/'); ?>plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo base_url('assets/backend/'); ?>plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo base_url('assets/frontend/default/css/modal.css'); ?>">
<style>
    .foodmenu-thumbnail-for-cart {
        height: 130px;
    }
</style>