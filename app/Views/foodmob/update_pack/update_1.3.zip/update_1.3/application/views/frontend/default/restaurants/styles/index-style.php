<style media="screen">
  .btn-group1 {
    width: 73%;
  }

  @media (max-width: 576px) {
    .btn-group1 {
      width: 100%;
      border-radius: 3px;
      margin: 0 0 10px;
      padding: 17px;
    }
  }
</style>