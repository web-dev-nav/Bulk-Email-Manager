<!-- Magnific popup JS -->
<script src="<?php echo base_url('assets/frontend/default/js/jquery.magnific-popup.js') ?>"></script>
<!-- Swipper Slider JS -->
<script src="<?php echo base_url('assets/frontend/default/js/swiper.min.js') ?>"></script>

<!-- Leaflet JS -->
<script src="<?php echo base_url('assets/global/leaflet/leaflet.js'); ?>"></script>

<!-- INIT JS -->
<script src="<?php echo base_url('assets/frontend/default/js/init.js') ?>"></script>
<script>
  "use strict";

  var swiper = new Swiper('.swiper-container', {
    slidesPerView: 3,
    slidesPerGroup: 3,
    loop: true,
    loopFillGroupWithBlank: true,
    pagination: {
      el: '.swiper-pagination',
      clickable: true,
    },
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
  });

  if ($('.image-link').length) {
    $('.image-link').magnificPopup({
      type: 'image',
      gallery: {
        enabled: true
      }
    });
  }
  if ($('.image-link2').length) {
    $('.image-link2').magnificPopup({
      type: 'image',
      gallery: {
        enabled: true
      }
    });
  }

  // INITIALIZE TOOLTIPS
  initToolTip();

  // CART OPERATIONS
  function addToCart(menuId, servings, quantity, note) {
    $.ajax({
      url: '<?php echo site_url('cart/add_to_cart'); ?>',
      type: 'POST',
      data: {
        menuId: menuId,
        quantity: quantity,
        servings: servings,
        note: note
      },
      success: function(response) {
        if (response === "false") {
          toastr.warning('<?php echo site_phrase('please_login_first'); ?>');
        } else {
          if (Math.floor(response) == response && $.isNumeric(response)) {
            $('.cart-items').text(response);
            toastr.success('<?php echo site_phrase('added_to_the_cart'); ?>');
            $("#cart-modal").modal('hide');
          }
        }
      }
    });
  }

  // MAP INITIALIZING
  var map = L.map('map').setView([<?php echo !empty($restaurant_details['latitude']) ? floatval(sanitize($restaurant_details['latitude'])) : 0; ?>, <?php echo !empty($restaurant_details['longitude']) ? floatval(sanitize($restaurant_details['longitude'])) : 0; ?>], 16);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

  L.marker([<?php echo !empty($restaurant_details['latitude']) ? floatval(sanitize($restaurant_details['latitude'])) : 0; ?>, <?php echo !empty($restaurant_details['longitude']) ? floatval(sanitize($restaurant_details['longitude'])) : 0; ?>]).addTo(map)
    .bindPopup('<?php echo sanitize($restaurant_details['address']); ?>');
</script>