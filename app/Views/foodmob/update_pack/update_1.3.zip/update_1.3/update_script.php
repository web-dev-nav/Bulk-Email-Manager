<?php
$CI = get_instance();
$CI->load->database();
$CI->load->dbforge();

// INSERT VERSION NUMBER INSIDE SETTINGS TABLE
$version_updater_sql = "UPDATE `system_settings` SET `value` = '1.3' WHERE `system_settings`.`key` = 'version'";
$CI->db->query($version_updater_sql);

// ADD FIELDS TO NOTE CART TABLE
$note_field = array(
  'note' => array('type' => 'LONGTEXT', 'null'  => TRUE)
);
$CI->dbforge->add_column('cart', $note_field);

// ADD FIELDS TO NOTE ORDER DETAILS TABLE
$note_field = array(
  'note' => array('type' => 'LONGTEXT', 'null'  => TRUE)
);
$CI->dbforge->add_column('order_details', $note_field);
