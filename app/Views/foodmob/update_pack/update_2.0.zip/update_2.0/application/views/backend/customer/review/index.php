<!-- Content Header -->
<?php include 'header.php'; ?>
<!-- /.content-header -->

<section class="content">
    <div class="container-fluid">
        <?php include "list.php"; ?>
    </div>
    <!--/. container-fluid -->
</section>
<!-- /.content -->