<!-- IMAGE UPLOAD WITH PREVIEW -->
<link rel="stylesheet" href="<?php echo base_url('assets/backend/'); ?>css/file-upload-preview.css">
<!-- Select2 -->
<link rel="stylesheet" href="<?php echo base_url('assets/backend/'); ?>plugins/select2/css/select2.min.css">
