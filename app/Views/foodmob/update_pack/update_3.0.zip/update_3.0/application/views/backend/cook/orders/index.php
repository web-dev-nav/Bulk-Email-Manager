<!-- Content Header -->
<?php include 'header.php'; ?>
<!-- /.content-header -->

<section class="content">
    <div class="container-fluid">
        <?php include "$order_type.php"; ?>
    </div>
    <!--/. container-fluid -->
</section>
<!-- /.content -->