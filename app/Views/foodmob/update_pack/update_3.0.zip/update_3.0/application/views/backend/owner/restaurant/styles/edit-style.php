<!-- Select2 -->
<link rel="stylesheet" href="<?php echo base_url('assets/backend/'); ?>plugins/select2/css/select2.min.css">

<!-- Bootstrap iCheck -->
<link rel="stylesheet" href="<?php echo base_url('assets/backend/'); ?>plugins/icheck-bootstrap/icheck-bootstrap.min.css">

<!-- Bootstrap Taginputs -->
<link rel="stylesheet" href="<?php echo base_url('assets/backend/'); ?>css/tags-input.css">

<!-- IMAGE UPLOAD WITH PREVIEW -->
<link rel="stylesheet" href="<?php echo base_url('assets/backend/'); ?>css/file-upload-preview.css">

<!-- TIME PICKER -->
<link rel="stylesheet" href="<?php echo base_url('assets/backend/'); ?>css/bootstrap-clockpicker.min.css">