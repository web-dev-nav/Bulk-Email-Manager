<!-- LEAFLET CSS -->
<link rel="stylesheet" href="<?php echo base_url('assets/global/leaflet/leaflet.css'); ?>">

<style>
    #mapid1 {
        height: 260px;
    }

    #mapid2 {
        height: 260px;
    }

    #mapid3 {
        height: 260px;
    }


    .note {
        font-size: 13px;
    }
</style>