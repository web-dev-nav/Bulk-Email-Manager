<!-- Content Header -->
<?php include 'header.php'; ?>

<section class="content">
    <div class="container-fluid">
        <?php include "tiles.php"; ?>
        <?php include "list.php"; ?>
    </div>
</section>
<!-- /.content -->